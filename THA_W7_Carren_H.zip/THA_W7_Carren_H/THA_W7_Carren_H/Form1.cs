﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace THA_W7_Carren_H
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            PictureBox pb1 = new PictureBox();
            pb1.Image = Image.FromFile("../shazam.jpg");
            pb1.Location = new Point(20, 20);
            pb1.Size = new Size(150, 150);
            pb1.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(pb1);

            Label lbl_shazam = new Label();
            lbl_shazam.Text = "Shazam";
            lbl_shazam.Location = new Point(60, 175);
            lbl_shazam.Size = new Size(160, 20);
            this.Controls.Add(lbl_shazam);

            Button btn_shazam =new Button();
            btn_shazam.Text = "Reserve";
            btn_shazam.Location = new Point(50, 196);
            btn_shazam.Size = new Size(55, 19);
            this.Controls.Add(btn_shazam);

            btn_shazam.Click += Btn_shazam_Click;

            PictureBox bullet = new PictureBox();
            bullet.Image = Image.FromFile("../bullet train.jpg");
            bullet.Location = new Point(20, 220);
            bullet.Size = new Size(150, 150);
            bullet.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(bullet);

            Label lbl_bullet = new Label();
            lbl_bullet.Text = "Bullet Train";
            lbl_bullet.Location = new Point(70, 380);
            lbl_bullet.Size = new Size(160, 20);
            this.Controls.Add(lbl_bullet);

            Button btn_bullet = new Button();
            btn_bullet.Text = "Reserve";
            btn_bullet.Location = new Point(65, 400);
            btn_bullet.Size = new Size(55, 19);
            this.Controls.Add(btn_bullet);

            btn_bullet.Click += Btn_bullet_Click;

            PictureBox dillan = new PictureBox();
            dillan.Image = Image.FromFile("../dilan 1990.jpg");
            dillan.Location = new Point(220, 20);
            dillan.Size = new Size(150, 150);
            dillan.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(dillan);

            Label lbl_dilan = new Label();
            lbl_dilan.Text = "Dilan 1990";
            lbl_dilan.Location = new Point(260, 180);
            lbl_dilan.Size = new Size(160, 20);
            this.Controls.Add(lbl_dilan);

            Button btn_dilan = new Button();
            btn_dilan.Text = "Reserve";
            btn_dilan.Location = new Point(260, 199);
            btn_dilan.Size = new Size(65, 19);
            this.Controls.Add(btn_dilan);

            btn_dilan.Click += Btn_dilan_Click;

            PictureBox strange = new PictureBox();
            strange.Image = Image.FromFile("../DR.strange.jpeg");
            strange.Location = new Point(400, 20);
            strange.Size = new Size(150, 150);
            strange.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(strange);

            Label lbl_strange = new Label();
            lbl_strange.Text = "Dr.Strange";
            lbl_strange.Location = new Point(450, 180);
            lbl_strange.Size = new Size(160, 20);
            this.Controls.Add(lbl_strange);

            Button btn_strange = new Button();
            btn_strange.Text = "Reserve";
            btn_strange.Location = new Point(449, 199);
            btn_strange.Size = new Size(65, 19);
            this.Controls.Add(btn_strange);

            btn_strange.Click += Btn_strange_Click;

            PictureBox fivecm = new PictureBox();
            fivecm.Image = Image.FromFile("../5_cm_(poster).jpg");
            fivecm.Location = new Point(600, 20);
            fivecm.Size = new Size(150, 150);
            fivecm.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(fivecm);

            Label lbl_fivecm = new Label();
            lbl_fivecm.Text = "5 CM";
            lbl_fivecm.Location = new Point(660, 180);
            lbl_fivecm.Size = new Size(160, 20);
            this.Controls.Add(lbl_fivecm);

            Button btn_fivecm = new Button();
            btn_fivecm.Text = "Reserve";
            btn_fivecm.Location = new Point(645, 199);
            btn_fivecm.Size = new Size(65, 19);
            this.Controls.Add(btn_fivecm);

            btn_fivecm.Click += Btn_fivecm_Click;

            PictureBox eternal = new PictureBox();
            eternal.Image = Image.FromFile("../eternals.jpg");
            eternal.Location = new Point(220, 220);
            eternal.Size = new Size(150, 150);
            eternal.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(eternal);

            Label lbl_eternal = new Label();
            lbl_eternal.Text = "Eternal";
            lbl_eternal.Location = new Point(280, 380);
            lbl_eternal.Size = new Size(160, 20);
            this.Controls.Add(lbl_eternal);

            Button btn_eternal= new Button();
            btn_eternal.Text = "Reserve";
            btn_eternal.Location = new Point(270, 399);
            btn_eternal.Size = new Size(65, 19);
            this.Controls.Add(btn_eternal);

            btn_eternal.Click += Btn_eternal_Click;

            PictureBox urname = new PictureBox();
            urname.Image = Image.FromFile("../your name.jpg");
            urname.Location = new Point(410, 220);
            urname.Size = new Size(150, 150);
            urname.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(urname);

            Label lbl_urname = new Label();
            lbl_urname.Text = "Your Name";
            lbl_urname.Location = new Point(450, 380);
            lbl_urname.Size = new Size(160, 20);
            this.Controls.Add(lbl_urname);

            Button btn_urname = new Button();
            btn_urname.Text = "Reserve";
            btn_urname.Location = new Point(450, 399);
            btn_urname.Size = new Size(65, 19);
            this.Controls.Add(btn_urname);

            btn_urname.Click += Btn_urname_Click;

            PictureBox minion = new PictureBox();
            minion.Image = Image.FromFile("../minion.jpg");
            minion.Location = new Point(600, 220);
            minion.Size = new Size(150, 150);
            minion.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(minion);

            Label lbl_minion = new Label();
            lbl_minion.Text = "Minion";
            lbl_minion.Location = new Point(650, 380);
            lbl_minion.Size = new Size(160, 20);
            this.Controls.Add(lbl_minion);

            Button btn_minion = new Button();
            btn_minion.Text = "Reserve";
            btn_minion.Location = new Point(635, 399);
            btn_minion.Size = new Size(65, 19);
            this.Controls.Add(btn_minion);

            btn_minion.Click += Btn_minion_Click;

         
        }

        private void Btn_bullet_Click(object sender, EventArgs e)
        {
            bullet peluru = new bullet();
            peluru.Show();


        }

        private void Btn_dilan_Click(object sender, EventArgs e)
        {
            dilan dilan = new dilan();
            dilan.Show();
        }

        private void Btn_strange_Click(object sender, EventArgs e)
        {
            Dr strange = new Dr();
            strange.Show();
        }

        private void Btn_fivecm_Click(object sender, EventArgs e)
        {
            fivecm limacm = new fivecm();
            limacm.Show();
        }

        private void Btn_eternal_Click(object sender, EventArgs e)
        {
            eternal abadi = new eternal();
            abadi.Show();
        }

        private void Btn_urname_Click(object sender, EventArgs e)
        {
            urname namau = new urname();
            namau.Show();
        }

        private void Btn_minion_Click(object sender, EventArgs e)
        {
            minion mini= new minion();
            mini.Show();
        }

        private void Btn_shazam_Click(object sender, EventArgs e)
        {
            shazam shazam = new shazam();
            shazam.Show();
        }
    }
    
}
