﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace THA_W7_Carren_H
{
    public partial class dilan : Form
    {
        List<Button> jam10 = new List<Button>();
        List<Button> jam12 = new List<Button>();
        List<Button> jam14 = new List<Button>();
        int x = 0;
        int y = 0;
        int abc = 0;
        int mnl = 0;

        Panel panel_dilan = new Panel();
        Random seat = new Random();
        Label label_seat = new Label();
        public dilan()
        {
            InitializeComponent();
            this.BackColor = Color.LightSteelBlue;
            PictureBox pb1 = new PictureBox();
            pb1.Image = Image.FromFile("../dilan 1990.jpg");
            pb1.Location = new Point(20, 20);
            pb1.Size = new Size(350, 350);
            pb1.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(pb1);

            label_seat.AutoSize = true;
            label_seat.Location = new Point(380, 220);
            label_seat.Name = "Choosen Seat: ";
            label_seat.Size = new Size(300, 300);
            label_seat.TabIndex = 1;
            label_seat.Text = "Choosen Seat: ";
            Controls.Add(label_seat);
            label_seat.Click += Label_seat_Click;

            Button btn_jam10 = new Button();
            btn_jam10.Text = "10:00";
            btn_jam10.Location = new Point(445, 56);
            btn_jam10.Size = new Size(55, 30);
            btn_jam10.BackColor = Color.AntiqueWhite;
            this.Controls.Add(btn_jam10);
            btn_jam10.Click += Btn_jam10_Click;

            Button btn_jam12 = new Button();
            btn_jam12.Text = "12:00";
            btn_jam12.Location = new Point(445, 96);
            btn_jam12.Size = new Size(55, 30);
            btn_jam12.BackColor = Color.AntiqueWhite;
            this.Controls.Add(btn_jam12);
            btn_jam12.Click += Btn_jam12_Click;

            Button btn_jam14 = new Button();
            btn_jam14.Text = "14:00";
            btn_jam14.Location = new Point(445, 136);
            btn_jam14.Size = new Size(55, 30);
            btn_jam14.BackColor = Color.AntiqueWhite;
            this.Controls.Add(btn_jam14);
            btn_jam14.Click += Btn_jam14_Click;

            Button btn_back = new Button();
            btn_back.Text = "Back";
            btn_back.Location = new Point(445, 176);
            btn_back.Size = new Size(55, 30);
            btn_back.BackColor = Color.AntiqueWhite;
            this.Controls.Add(btn_back);
            btn_back.Click += Btn_back_Click;

            Button btn_reset = new Button();
            btn_reset.Text = "Reset";
            btn_reset.Location = new Point(445, 245);
            btn_reset.Size = new Size(50, 30);
            btn_reset.BackColor = Color.AntiqueWhite;
            this.Controls.Add(btn_reset);
            btn_reset.Click += Btn_reset_Click;

            Label lbl_layar = new Label();
            lbl_layar.Text = "-------------------Layar------------------";
            lbl_layar.Size = new Size(300, 300);
            lbl_layar.Name = "Layar";
            lbl_layar.Location = new Point(60, 310);
            this.Controls.Add(lbl_layar);
            this.panel_dilan.Controls.Add(lbl_layar);

            panel_dilan.Location = new Point(528, 20);
            panel_dilan.Size = new Size(255, 362);
            panel_dilan.BackColor = Color.LightPink;
            this.Controls.Add(panel_dilan);

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Button button14 = new Button();
                    button14.Tag = j.ToString() + "," + i.ToString();
                    button14.Size = new Size(25, 25);
                    button14.Location = new Point(2 + x, 2 + y);
                    button14.BackColor = Color.Transparent;
                    button14.Click += Button14_Click;
                    jam14.Add(button14);
                    abc++;
                    y += 27;
                    panel_dilan.Controls.Add(button14);
                }
                y = 0;
                x += 25;


            }

            for (int i = 0; i < 70; i++)
            {
                panel_dilan.Controls.Clear();
                int random = seat.Next(0, 100);
                jam14[random].BackColor = Color.Red;
                jam14[random].Enabled = false;
            }

            x = 0;
            y = 0;
            panel_dilan.Controls.Clear();
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Button button12 = new Button();
                    button12.Tag = j.ToString() + "," + i.ToString();
                    button12.Size = new Size(25, 25);
                    button12.Location = new Point(2 + x, 2 + y);
                    button12.BackColor = Color.Transparent;
                    button12.Click += Button12_Click;
                    jam12.Add(button12);
                    abc++;
                    y += 27;
                    panel_dilan.Controls.Add(button12);
                }
                y = 0;
                x += 25;


            }

            for (int i = 0; i < 70; i++)
            {
                panel_dilan.Controls.Clear();
                int random = seat.Next(0, 100);
                jam12[random].BackColor = Color.Red;
                jam12[random].Enabled = false;
            }

            x = 0;
            y = 0;
            panel_dilan.Controls.Clear();
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Button button10 = new Button();
                    button10.Tag = j.ToString() + "," + i.ToString();
                    button10.Size = new Size(25, 25);
                    button10.Location = new Point(2 + x, 2 + y);
                    button10.BackColor = Color.Transparent;
                    button10.Click += Button10_Click;
                    jam10.Add(button10);
                    abc++;
                    y += 27;
                    panel_dilan.Controls.Add(button10);
                }
                y = 0;
                x += 25;


            }

            for (int i = 0; i < 70; i++)
            {
                panel_dilan.Controls.Clear();
                int random = seat.Next(0, 100);
                jam10[random].BackColor = Color.Red;
                jam10[random].Enabled = false;
            }


        }

        private void Btn_reset_Click(object sender, EventArgs e)
        {
            if (mnl == 10)
            {
                foreach (Button button in jam10)
                {
                    if (button.BackColor == Color.GreenYellow)
                    {
                        button.BackColor = Color.Red;
                        button.Enabled = false;
                    }
                }
            }
            if (mnl == 12)
            {
                foreach (Button button in jam12)
                {
                    if (button.BackColor == Color.GreenYellow)
                    {
                        button.BackColor = Color.Red;
                        button.Enabled = false;
                    }
                }
            }
            if (mnl == 14)
            {
                foreach (Button button in jam14)
                {
                    if (button.BackColor == Color.GreenYellow)
                    {
                        button.BackColor = Color.Red;
                        button.Enabled = false;
                    }
                }
            }
        }

        private void Btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button10_Click(object sender, EventArgs e)
        {
            panel_dilan.Controls.Clear();
            foreach (Button seat in jam10)
            {
                panel_dilan.Controls.Add(seat);
            }
            Button button = sender as Button;
            if (button.BackColor == Color.Transparent)
            {
                button.BackColor = Color.GreenYellow;
                label_seat.Text += button.Tag.ToString() + " | ";
            }
            MessageBox.Show(" Choosen seat: " + button.Tag.ToString());
        }

        private void Button12_Click(object sender, EventArgs e)
        {
            panel_dilan.Controls.Clear();
            foreach (Button seat in jam12)
            {
                panel_dilan.Controls.Add(seat);
            }
            Button button = sender as Button;
            if (button.BackColor == Color.Transparent)
            {
                button.BackColor = Color.GreenYellow;
                label_seat.Text += button.Tag.ToString() + " | ";
            }
            MessageBox.Show(" Choosen seat: " + button.Tag.ToString());
        }

        private void Label_seat_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Button14_Click(object sender, EventArgs e)
        {
            panel_dilan.Controls.Clear();
            foreach (Button seat in jam14)
            {
                panel_dilan.Controls.Add(seat);
            }
            Button button = sender as Button;
            if (button.BackColor == Color.Transparent)
            {
                button.BackColor = Color.GreenYellow;
                label_seat.Text += button.Tag.ToString() + " | ";
            }
            MessageBox.Show(" Choosen seat: " + button.Tag.ToString());
        }

        private void Btn_jam14_Click(object sender, EventArgs e)
        {
            panel_dilan.Controls.Clear();
            mnl = 14;
            foreach (Button seat in jam14)
            {
                panel_dilan.Controls.Add(seat);
            }
        }

        private void Btn_jam12_Click(object sender, EventArgs e)
        {
            panel_dilan.Controls.Clear();
            mnl = 12;
            foreach (Button seat in jam12)
            {
                panel_dilan.Controls.Add(seat);
            }
        }

        private void Btn_jam10_Click(object sender, EventArgs e)
        {
            panel_dilan.Controls.Clear();
            mnl = 10;
            foreach (Button seat in jam10)
            {
                panel_dilan.Controls.Add(seat);
            }
        }
    }
}

